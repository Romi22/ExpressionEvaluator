package evaluator.helper;

import java.util.List;

public abstract class  Operator
{
    public abstract void validOperators();
    public abstract List<String> getOperators();
}
